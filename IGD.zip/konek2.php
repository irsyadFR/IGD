<?php	
	$connection = mysql_connect("localhost", "root", "");
	$db = mysql_select_db("IGD", $connection);
?>