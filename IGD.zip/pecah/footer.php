<div class="container">
	<div class="row">
		<div class="8u 12u$(medium)">
			<ul class="copyright">
				<li>&copy; IGD RS DR Oen</li>
				<li>Design: Kelompok 5 Anapersis Menpro</li>
			</ul>
		</div>
		<!-- <div class="4u$ 12u$(medium)">
			<ul class="icons">
				<li>
					<a href="http//www.facebook.com" class="icon rounded fa-facebook"><span class="label">Facebook</span></a>
				</li>
				<li>
					<a class="icon rounded fa-twitter"><span class="label">Twitter</span></a>
				</li>
				<li>
					<a class="icon rounded fa-google-plus"><span class="label">Google+</span></a>
				</li>
				<li>
					<a class="icon rounded fa-linkedin"><span class="label">LinkedIn</span></a>
				</li>
			</ul>
		</div> -->
	</div>
</div>